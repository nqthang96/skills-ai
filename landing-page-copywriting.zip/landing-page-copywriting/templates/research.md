# RESEARCH — Nghiên cứu sản phẩm & khách hàng

> Điền càng nhiều càng tốt. Thông tin chất lượng = nội dung chất lượng.
> Mục có dấu (*) quan trọng hơn, ưu tiên điền trước.

---

## 1. Tổng quan sản phẩm / dịch vụ (*)

```
[Mô tả ngắn gọn: sản phẩm/dịch vụ là gì, phục vụ ai, giải quyết vấn đề gì]
```

---

## 2. Mô tả chi tiết sản phẩm / dịch vụ

```
[Mô tả đầy đủ hơn về sản phẩm/dịch vụ]
```

---

## 3. Tính năng chính (*)

```
- Tính năng 1:
- Tính năng 2:
- Tính năng 3:
[Thêm nếu cần]
```

---

## 4. Công dụng / Lợi ích (*)

> Sản phẩm giúp gì cho người dùng? Kết quả cụ thể họ nhận được là gì?

```
[Điền vào đây]
```

---

## 5. USP / Điểm khác biệt (*)

> Vì sao khách hàng nên chọn bạn chứ không phải đối thủ?

```
[Điền vào đây]
```

---

## 6. Giá bán / Gói dịch vụ

```
[Điền vào đây hoặc ghi "Chưa công bố"]
```

---

## 7. Bằng chứng uy tín (*)

> Case study, testimonial, số liệu, chứng nhận, truyền thông, chuyên gia endorsement, khách hàng đã dùng...

```
[Điền vào đây — càng cụ thể càng tốt: tên, kết quả, trích dẫn thực]
```

---

## 8. Đối thủ cạnh tranh

```
[Tên đối thủ chính và điểm khác biệt so với họ nếu có]
```

---

## 9. Insight khách hàng

> Những hiểu biết sâu về tâm lý, hành vi, thói quen của khách hàng mục tiêu nếu có.

```
[Điền vào đây hoặc để trống]
```

---

## 10. Vấn đề / Nỗi đau của khách hàng (*)

> Họ đang gặp khó khăn gì? Điều gì đang làm họ khổ sở, lo lắng, bực bội?

```
[Điền vào đây — càng cụ thể và cảm xúc càng tốt]
```

---

## 11. Mong muốn / Khao khát của khách hàng (*)

> Họ muốn đạt được kết quả gì? Cuộc sống lý tưởng của họ trông như thế nào?

```
[Điền vào đây]
```

---

## 12. Rào cản chưa mua hàng (*)

> Điều gì khiến họ chần chừ, chưa hành động? Họ đang nghĩ gì, lo gì?

```
- Rào cản 1:
- Rào cản 2:
- Rào cản 3:
[Thêm nếu cần]
```

---

## 13. Phản đối thường gặp

> Những câu hỏi/nghi ngờ phổ biến khi khách hàng cân nhắc mua.

```
- "..."
- "..."
[Thêm nếu cần]
```

---

## 14. Yêu cầu đặc biệt

> Yêu cầu về nội dung, thương hiệu, ngôn ngữ, pháp lý, hoặc điều **không được** đề cập.

```
[Điền vào đây hoặc ghi "Không có"]
```