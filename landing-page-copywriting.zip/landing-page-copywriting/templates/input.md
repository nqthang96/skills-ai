# INPUT — Thông tin chiến dịch

> Điền đầy đủ các mục bên dưới. Mục có dấu (*) là bắt buộc.

---

## A. Thông tin bắt buộc

**Mục tiêu landing page (*)**
> Ví dụ: Thu lead, bán hàng trực tiếp, đăng ký webinar, dùng thử miễn phí...

```
[Điền vào đây]
```

**Đối tượng khách hàng mục tiêu (*)**
> Mô tả càng cụ thể càng tốt: độ tuổi, nghề nghiệp, vấn đề đang gặp, hành vi...

```
[Điền vào đây]
```

**Traffic source chính (*)**
> Ví dụ: Facebook Ads, Google Ads, Email marketing, SEO, TikTok Ads, Referral...
> Nếu có nhiều kênh, ghi rõ kênh chính.

```
[Điền vào đây]
```

**Ưu đãi / Incentive trong chiến dịch này (*)**
> Có ưu đãi, quà tặng, bonus, voucher, trial, guarantee hoặc incentive nào không?
> Nếu không có, ghi "Không có".

```
[Điền vào đây]
```

---

## B. Thông tin tùy chọn

> Nếu không điền, AI sẽ tự xác định dựa trên thông tin đã cung cấp và sẽ khai báo rõ giả định.

**Awareness Level**
> Khách hàng đang ở tầng nào?
> [ ] Unaware — Chưa biết mình có vấn đề
> [ ] Problem-aware — Biết vấn đề, chưa biết giải pháp
> [ ] Solution-aware — Biết loại giải pháp, chưa biết chọn ai
> [ ] Product-aware — Biết sản phẩm của bạn, chưa mua
> [ ] Most-aware — Sẵn sàng mua, chỉ cần offer rõ

```
[Chọn hoặc để trống]
```

**Loại landing page theo mục tiêu**
> Để trống nếu muốn AI tự chọn.

```
[Điền vào đây hoặc để trống]
```

**Loại landing page theo format content**
> Để trống nếu muốn AI tự chọn.

```
[Điền vào đây hoặc để trống]
```

**Tone of voice**
> Để trống nếu muốn AI tự chọn.

```
[Điền vào đây hoặc để trống]
```

**Copywriting style**
> Để trống nếu muốn AI tự chọn.

```
[Điền vào đây hoặc để trống]
```

**Marketing angle / Thông điệp chính muốn nhấn mạnh**
> Để trống nếu muốn AI tự đề xuất.

```
[Điền vào đây hoặc để trống]
```

**Viết theo phong cách chuyên gia nào không?**
> Ví dụ: Joanna Wiebe, Dan S. Kennedy, Russell Brunson, Gary Bencivenga, Frank Kern, Alex Cattoni
> Để trống = không theo chuyên gia cụ thể nào.

```
[Điền vào đây hoặc để trống]
```

**Reference landing page**
> URL, mô tả, ảnh chụp hoặc nội dung trang tham khảo nếu có.

```
[Điền vào đây hoặc để trống]
```