# CONTENT WIREFRAME — [Tên sản phẩm / Chiến dịch]

> Bản Content Wireframe hoàn chỉnh. Mỗi section là một khối nội dung độc lập,
> sẵn sàng để designer / developer / copywriter triển khai thành landing page thực tế.

---

## Thông tin tổng quan

| Hạng mục | Nội dung |
|---|---|
| Sản phẩm / Dịch vụ | |
| Mục tiêu chuyển đổi | |
| Tone of voice | |
| Copywriting style | |
| Awareness level | |
| Big Idea | |
| Promise chính | |

---

## Wireframe

---

## Section 1: [Tên section]

**Mục tiêu:** [Khách hàng cần cảm nhận / hiểu / tin điều gì sau section này?]

---

**Primary Title (Headline chính):**
```
[Viết headline tại đây — rõ ràng, có hook, phù hợp awareness level]
```

**Secondary Title / Subtitle:**
```
[Hỗ trợ, làm rõ hoặc kéo dài sức hút của headline]
```

**Body Content:**
```
[Nội dung chính của section]
```

**Key Highlights / Bullet Points:** *(nếu có)*
- [Benefit / kết quả 1 — không chỉ là tính năng]
- [Benefit / kết quả 2]
- [Benefit / kết quả 3]

**Trust Element / Bằng chứng:** *(nếu có)*
```
[Testimonial, số liệu, logo, chứng nhận...]
```

**CTA:** *(nếu có)*
```
[Text CTA]
[Ghi chú: vị trí, sub-text dưới nút nếu cần]
```

**Ghi chú copywriting:**
```
[Công thức, hiệu ứng tâm lý, NLP technique áp dụng]
```

---

## Section 2: [Tên section]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**Key Highlights / Bullet Points:** *(nếu có)*
-
-
-

**Trust Element / Bằng chứng:** *(nếu có)*
```

```

**CTA:** *(nếu có)*
```

```

**Ghi chú copywriting:**
```

```

---

## Section 3: [Tên section]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**Key Highlights / Bullet Points:** *(nếu có)*
-
-
-

**Trust Element / Bằng chứng:** *(nếu có)*
```

```

**CTA:** *(nếu có)*
```

```

**Ghi chú copywriting:**
```

```

---

## Section 4: [Tên section]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**Key Highlights / Bullet Points:** *(nếu có)*
-
-
-

**Trust Element / Bằng chứng:** *(nếu có)*
```

```

**CTA:** *(nếu có)*
```

```

**Ghi chú copywriting:**
```

```

---

## Section 5: [Tên section]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**Key Highlights / Bullet Points:** *(nếu có)*
-
-
-

**Trust Element / Bằng chứng:** *(nếu có)*
```

```

**CTA:** *(nếu có)*
```

```

**Ghi chú copywriting:**
```

```

---

## Section 6: [Tên section]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**Key Highlights / Bullet Points:** *(nếu có)*
-
-
-

**Trust Element / Bằng chứng:** *(nếu có)*
```

```

**CTA:** *(nếu có)*
```

```

**Ghi chú copywriting:**
```

```

---

## Section 7: [Tên section — FAQ / Xử lý phản đối]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Body Content — FAQ format:**
```
Q: [Câu hỏi / phản đối thường gặp]
A: [Trả lời xử lý rào cản]

Q:
A:

Q:
A:
```

**Ghi chú copywriting:**
```

```

---

## Section 8: [Tên section — Final CTA / Closing]

**Mục tiêu:**

---

**Primary Title:**
```

```

**Secondary Title / Subtitle:**
```

```

**Body Content:**
```

```

**CTA:**
```
[Text CTA chính]
[Sub-text hoặc guarantee dưới nút — VD: "Miễn phí 100% • Không cần thẻ tín dụng"]
```

**Ghi chú copywriting:**
```

```

---

> ⚙️ *AI thêm hoặc bớt section theo outline đã được duyệt. Template trên là khung tham chiếu.*

---