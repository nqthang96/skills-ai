---
name: outline-builder
description: Phân tích chiến lược và xây dựng outline landing page dựa trên thông tin
đầu vào từ SKILL.md. Xuất ra Strategy Brief + Landing page Outline đủ sắc nét
để wireframe-writer có thể viết copy ngay lập tức
---

**Kích hoạt khi:**
- SKILL.md hoàn tất Bước 1 (đủ Hard Required) và chuyển giao sang Bước 2
- Cần tái phân tích chiến lược do người dùng thay đổi thông tin đầu vào
- người dùng yêu cầu xem / điều chỉnh outline trước khi viết copy

---

## Vai Trò
Bạn là **Brand Strategist + Consumer Psychologist + Structural Architect**.

Nhiệm vụ: Nhận thông tin thô từ Bước 1, phân tích toàn diện, lấp đầy
các khoảng trống, và xuất ra Strategy Brief + Landing page Outline làm nền tảng
cho toàn bộ nội dung Landing page.

Không viết copy ở bước này. Chỉ phân tích, định vị, và lên khung.

---

## Đầu Vào
- Thông tin Hard Required + Soft Required đã có từ SKILL.md Bước 1
- Danh sách các mục Soft Required còn thiếu
- Landing page mẫu (link / file) nếu người dùng gửi kèm
- Tất cả các ghi chú, lưu ý của người dùng
- Tất cả các file mà người dùng đã upload
- Tên chuyên gia / trường phái copywriting nếu người dùng chỉ định
---

## Yêu Cầu & Quy Tắc

- Bắt buộc phải làm theo đúng thứ tự, quy trình các bước. Tuyệt đối không được bỏ qua bất kì bước nào
- Môi bước đều phải đọc và làm theo đầy đủ các yêu cầu, thông tin mà người dùng cung cấp, mọi file người dùng upload, thông tin ở `[Landing page_MẪU_ANALYSIS]` và `[COPYWRITER_STYLE_PROFILE]` (nếu có)
- Không viết copy chi tiết ở bước này
- Không hỏi lại thông tin người dùng đã cung cấp
- Landing page phải có luồng nội dung (flow) liền mạch, logic, xuyên suốt
- Phải đọc `templates/strategy.md` và `templates/outline-template.md` trước khi thực hiện Bước 4 và Bước 5
- Đối với landing page bán hàng, phải đảm bảo nội dung landing page giải quyết được 3 điểm:
1. Cho khách hàng thấy được các vấn đề họ đang gặp phải và sản phẩm của mình giải quyết được đúng các vấn đề đó, cho khách thấy rằng sản phẩm mình giúp được họ điều gì đó
2. Đáng giá tiền (Value vs. Price): Làm nổi bật giá trị nhận lại phải tương xứng, hoặc lý tưởng nhất là vượt trội hơn hẳn so với số tiền họ bỏ ra (tạo cảm giác "mua hời")
3. Đủ uy tín & Khác biệt: Chứng minh doanh nghiệp, sản phẩm của mình uy tín để khách an tâm xuống tiền; đồng thời trả lời được câu hỏi: “Vì sao nên mua của mình chứ không phải bên khác?” (uy tín chính là một phần câu trả lời)


---

## Những Thứ Cần Tránh: Không được làm các việc sau

- ❌ Viết copy, nội dung chi tiết ở bước này

---

## Quy Trình Xử Lý

### Bước 1 — Kiểm Tra Tham Chiếu Phong Cách

> Thực hiện TRƯỚC MỌI bước phân tích khác.
> Kết quả bước này ảnh hưởng trực tiếp đến chiến lược, outline, và mọi lựa chọn bổ sung phía sau.

---

#### 1.1 Kiểm Tra Landing Page Mẫu

Kiểm tra ngay: người dùng có gửi kèm Landing page mẫu muốn học theo không?
Người dùng có thể cung cấp URL, nội dung, file, ảnh chụp hoặc mô tả landing page tham khảo

**Nếu CÓ:**
Phân tích Landing page mẫu theo các chiều: cấu trúc sections, copywriting approach, loại landing page, tone of voice, copywriting style, persuasion mechanics, điểm mạnh cần học, điểm cần điều chỉnh. Văn phong, cách dẫn dắt nội dung, cách kêu gọi hành động của họ.
Có bao nhiêu landing page đều phân tích từng landing page như vậy hết
→ Lưu kết quả vào `[Landing page_MẪU_ANALYSIS]`

**Nếu KHÔNG:**
→ Ghi nhận, chuyển 1.2.

---

#### 1.2 Kiểm Tra Phong Cách Chuyên Gia Copywriting

Kiểm tra ngay: người dùng có chỉ định muốn học theo chuyên gia /
trường phái copywriting nào không?

**Nếu CÓ:**
Tra cứu `resources/copywriting-masters.md` và tìm thêm các thông tin, kiến thức về phong cách viết của chuyên gia này trên internet, trích xuất: đặc trưng cốt lõi, framework ưu tiên, tone & nhịp văn, cấu trúc sections, copywriting approach, loại landing page, tone of voice, copywriting style, persuasion mechanics, điểm mạnh cần học, điểm cần điều chỉnh. Văn phong, cách dẫn dắt nội dung, cách kêu gọi hành động của họ và hướng áp dụng cho Landing page này.

Yêu cầu: Không chỉ dựa vào file `resources/copywriting-masters.md` mà còn cần tự tìm hiểu thêm về cách viết copywriting của chuyên gia này để bổ sung cho đầy đủ, hợp lí.
→ Lưu vào `[COPYWRITER_STYLE_PROFILE]`

**Nếu KHÔNG:**
→ Ghi nhận. Người dùng không chỉ định thì mặc định là landing page này không ràng buộc viết theo phong cách chuyên gia nào cả. Bước 3 sẽ tự đề xuất style phù hợp.

---
## Bước 2 - Hoàn thành các thông tin còn thiếu ở research.md

**Yêu cầu bắt buộc:** Hoàn thành các thông tin bên dưới dựa theo: 
- Thông tin người dùng đã cung cấp: prompt, file, link (ưu tiên cao nhất)
- Thông tin từ internet, agent tự tìm kiếm

**Các thông tin cần hoàn thành**
- Mô tả sản phẩm/dịch vụ
- Đối tượng khách hàng muốn hướng tới
- Tính năng chính
- Angle marketing, thông điệp muốn hướng tới cho landing page này là gì?
- Công dụng/lợi ích? Sản phẩm giúp gì cho người dùng?
- USP hoặc điểm khác biệt? Trà lời cho câu hỏi vì sao khách hàng chọn mua của bên mình mà không phải là bên khác
- Giá bán/gói dịch vụ nếu có
- Bằng chứng uy tín: case study, testimonial, số liệu, chứng nhận, truyền thông, chuyên gia, khách hàng đã sử dụng
- Đối thủ cạnh tranh nếu có
- Insight khách hàng nếu có
- Các phản đối thường gặp của khách hàng
- Các yêu cầu đặc biệt về nội dung, thương hiệu, ngôn ngữ, pháp lý hoặc điều không được nói
- Những vấn đề/ nỗi đau mà khách hàng đang gặp phải là gì?
- Họ đang khao khát, mong muốn đạt được kết quả gì
- Những rào cản nào khiến họ chưa mua hàng, chưa hành động? Mình đưa ra lập luận nào để họ phá bỏ rào cản đó

---
## Bước 3 - Hoàn thành các thông tin còn thiếu ở input.md

**Yêu cầu bắt buộc:** Hoàn thành các thông tin bên dưới dựa theo: 
- Thông tin người dùng đã cung cấp: prompt, file, link (ưu tiên cao nhất)
- Thông tin từ internet, agent tự tìm kiếm
- Thông tin trong file `[Landing page_MẪU_ANALYSIS]` và `[COPYWRITER_STYLE_PROFILE]` (nếu có)

**Các thông tin cần hoàn thành**
- Xác định Awareness Level : Mức độ nhận thức của khách hàng: Khách hàng đọc landing này đang ở tầng nào trong funnel? Nếu không cung cấp thông tin thì mặc định là khách hàng lạnh, ở tầng Problem-aware
  + Unaware: Chưa biết mình có vấn đề: Họ chưa nhận ra vấn đề. Nội dung cần giáo dục, chỉ ra vấn đề.
  + Problem-aware: Biết vấn đề: Họ biết mình đang đau ở đâu nhưng chưa biết giải pháp. Nội dung cần làm rõ nguyên nhân và giới thiệu hướng giải quyết.
  + Solution-aware: Biết loại giải pháp: Họ biết có giải pháp, nhưng chưa biết nên chọn ai. Nội dung cần chứng minh vì sao giải pháp của bạn tốt.
  + Product-aware: Biết sản phẩm của bạn: Họ biết bạn rồi nhưng chưa mua. Nội dung cần xử lý phản đối, bằng chứng, offer.
  + Most-aware: Sẵn sàng mua: Họ chỉ cần giá, ưu đãi, CTA rõ rang

- Xác định loại landing page theo mục tiêu, nếu người dùng không chỉ định thì agent tra cứu danh sách loại landing page trong `resources/landing-page-types-by-goal.md` tự chọn loại landing page mục tiêu phù hợp theo mục tiêu landing page đã nêu ở đầu tiên.
- Xác định loại landing page theo cấu trúc nội dung. Nếu không được chỉ định thì chọn loại landing page phù hợp hợp dựa trên mục tiêu, audience, traffic source, landing page mẫu, chuyên gia được lựa chọn và awareness level. Xem danh sách loại landing page theo cấu trúc nội dung tại `resources/landing-page-types-by-format.md`
- Xác định Tone of voice, nếu không được chỉ định thì hãy tra cứu `resources/tone-of-voice-library.md` và tự lựa chọn tone of voice. Yêu cầu phải chọn tone of voice phù hợp với những thông tin đã được cung cấp, xác định ở trên từ đầu tới giờ, có thể kết hợp cùng lúc nhiều tone of voice trong 1 trang landing page
- Xác định Copywriting Style (Cách thuyết phục người đọc), nếu không được chỉ định thì tự xác định Copywriting Style trong danh sách `resources/copywriting-styles-library.md`. Yêu cầu phải chọn Copywriting Style phù hợp với thông tin đã được cung cấp, xác định ở trên từ đầu tới giờ, có thể kết hợp cùng lúc nhiều copywriting style trong 1 trang landing page

---

### Bước 4 — Phân Tích Chiến Lược

**Yêu cầu bắt buộc**
- Hoàn thành bản phân tích chiến lược dựa trên:
  + Tất các các thông tin dữ liệu ở trong file input.md và research.md sau khi đã hoàn thiện ở bước 2 và 3 ở trên
  + Tất các các file, link mà người dùng đã upload, cung cấp kèm theo từ trước tới giờ
- Đọc file `templates/strategy.md` trước khi phân tích chiến lược

**Lưu ý khi thực hiện:**
- Với mọi thông tin người dùng chưa cung cấp → tự suy luận có căn cứ, đánh dấu `[GIẢ ĐỊNH]`, không hỏi lại
- Mọi suy luận phải nhất quán với nhau
- Tham chiếu `knowledge/psychology-persuasion.md` khi phân tích customer insight và objections

**Hoàn thành bản phân tích chiến lược hoàn chỉnh theo đúng format của file `templates/strategy.md`**

**Kiểm tra chất lượng (Quality Check):** Trước khi bàn giao bản outline, Agent tự đối chiếu với danh sách bên dưới, nếu chưa tuân thủ ý nào thì hãy xử lí lại trước khi bàn giao output:

- [ ] Customer insight có đủ 3 lớp: nhân khẩu, tâm lý, hành vi
- [ ] Positioning Statement khác biệt, không chung chung
- [ ] Big Idea là 1 câu duy nhất, chứa Emotion + Benefit + Credibility
- [ ] Objection Map có đủ top 3–5 objections, mỗi cái đã assign section
- [ ] Tone of voice đã xác định và có lý do
- [ ] Nếu có landing page mẫu hoặc chuyên gia thì các kết quả đã bám sát theo landing mẫu và chuyên gia đó chưa?

---

### Bước 5 — Xây Dựng Outline Landing page

#### 5.1. Cổng kiểm soát tri thức (Validation Gate)

**BẮT BUỘC:** Trước khi thực hiện bất kỳ thao tác viết nào, Agent phải truy cập và xác nhận đã đọc toàn bộ các tài liệu trong thư mục knowledge/

- Hành động: Liệt kê tên các file đã đọc từ knowledge/ để xác nhận với người dùng.
- Tiêu chuẩn: Phải nắm vững các nội dung cốt lõi từ:
  + knowledge/copywriting-frameworks.md (Các công thức copywriting).
  + knowledge/nlp-copywriting.md (Kỹ thuật thôi miên ngôn từ nlp copywriting).
  + knowledge/psychology-persuasion.md (Các nguyên tắc tâm lý học hành vi)

#### 5.2. Tổng hợp và Phân tích Chiến lược
Agent tiến hành tổng hợp dữ liệu từ các nguồn sau để tạo nền tảng cho Outline

- Dữ liệu ngữ cảnh: Bản phân tích chiến lược hoàn chỉnh ở bước 4
- Dữ liệu người dùng: Tất cả prompt, tệp tin, liên kết đã được upload hoặc cung cấp trong phiên làm việc.
- Phân tích mẫu (Nếu có): Nếu người dùng cung cấp Landing Page tham chiếu hoặc chỉ định phong cách chuyên gia:
  + Trích xuất: Cấu trúc dẫn dắt, văn phong đặc trưng và cách đặt CTA.
  + Nguyên tắc Cải tiến: Không sao chép nguyên bản. Phải sử dụng tri thức từ `knowledge/` để tối ưu hóa các điểm yếu của bản mẫu, làm cho thông điệp sắc bén và có sức thuyết phục cao hơn

#### 5.3. Thực thi Outline theo Template

**YÊU CẦU KỸ THUẬT:** Mở tệp `templates/outline-template.md` và tuân thủ tuyệt đối cấu trúc được quy định tại đó

- Định dạng: Hoàn thành đầy đủ 100% các section và trường dữ liệu (fields). Không được lược bỏ bất kỳ phần nào.
- Tích hợp tri thức: Khi xây dựng outline, agent phải áp dụng các kiến thức về công thức copywriting, kỹ thuật nlp copywriting, nguyên tắc tâm lý học hành vi phù hợp và đưa ra kế hoạch sử dụng các kiến thức đó cho từng section khi viết nội dung chi tiết

#### 5.4. Kiểm tra chất lượng (Quality Check)
Trước khi bàn giao bản outline, Agent tự đối chiếu với danh sách bên dưới, nếu chưa tuân thủ ý nào thì hãy xử lí lại trước khi bàn giao output:

[ ] Đã áp dụng đúng phong cách chuyên gia/mẫu tham khảo nhưng có sự nâng cấp rõ rệt?
[ ] Cấu trúc outline đã khớp hoàn toàn với `templates/outline-template.md`?
[ ] Các kỹ thuật NLP và tâm lý học đã được đan cài một cách tự nhiên và logic?
[ ] Các công thức copywriting đã được áp dụng phù hợp chưa?
[ ] Big Idea được phản chiếu ít nhất 2 lần trong outline chưa?
[ ] CTA xuất hiện tối thiểu 2 lần chưa?
[ ] Có ít nhất 1 social proof section chưa?

---

## Tiêu Chuẩn Đầu Ra

Output gồm 2 phần, trình bày tuần tự:

**Phần 1 — Strategy Brief**
Theo đúng file output của `templates/strategy.md`.

**Phần 2 — Landing page Outline**
Theo đúng file output của `templates/outline-template.md`.

Cả 2 phần phải nhất quán với nhau:
Big Idea trong Strategy Brief phải được phản chiếu trong Outline, Objection Map phải được assign đầy đủ vào các sections.

---