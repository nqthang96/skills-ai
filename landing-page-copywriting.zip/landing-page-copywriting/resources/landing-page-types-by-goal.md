# Landing Page Types — Phân loại theo Mục tiêu

> AI tra file này để xác định loại landing page phù hợp dựa trên mục tiêu chiến dịch.

---

| Loại trang | Mục tiêu chính | Phù hợp với |
|---|---|---|
| Lead Generation Page | Lấy thông tin khách hàng | Dịch vụ, SaaS, B2B |
| Sales Page | Bán hàng trực tiếp | Khóa học, sản phẩm số, eCommerce |
| Product Landing Page | Giới thiệu sản phẩm | SaaS, app, sản phẩm vật lý |
| SaaS Landing Page | Đăng ký dùng thử / book demo | Phần mềm, AI tool |
| Service Landing Page | Lấy lịch tư vấn / báo giá | Agency, consultant, freelancer |
| Webinar Page | Kéo đăng ký sự kiện | Coaching, khóa học, B2B |
| Waitlist Page | Thu người dùng chờ launch | Startup, app mới |
| Coming Soon Page | Thông báo sắp ra mắt | Website, thương hiệu mới |
| Pre-Sell Page | Làm nóng trước khi bán | Affiliate, native ads |
| Affiliate Page | Đẩy click qua link affiliate | Review, comparison, coupon |
| Comparison Page | So sánh với đối thủ | SaaS, tool, dịch vụ |
| Pricing Page | Chuyển đổi sang trả phí | SaaS, membership |
| App Download Page | Kéo tải app | Mobile app, extension |
| Thank You Page | Xác nhận + upsell | Mọi loại funnel |
| Upsell / Downsell Page | Tăng giá trị đơn hàng | Funnel bán hàng |

---

## Hướng dẫn chọn nhanh theo mục tiêu

| Mục tiêu | Loại LP phù hợp |
|---|---|
| Thu email / lead | Lead Generation Page |
| Bán hàng trực tiếp | Sales Page |
| Đăng ký dùng thử phần mềm | SaaS Landing Page |
| Đặt lịch tư vấn / báo giá | Service Landing Page |
| Đăng ký sự kiện / webinar | Webinar Page |
| Ra mắt sản phẩm mới | Waitlist Page / Coming Soon Page |
| Làm ấm traffic lạnh trước khi bán | Pre-Sell Page |
| Khách đang so sánh đối thủ | Comparison Page |
| Bán thêm cho khách đã mua | Upsell / Downsell Page |
| Kéo tải app | App Download Page |