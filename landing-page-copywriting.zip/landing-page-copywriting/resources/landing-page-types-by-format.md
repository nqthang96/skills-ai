# Landing Page Types — Phân loại theo Cấu trúc Nội dung (Format Content)

> AI tra file này để xác định format content phù hợp dựa trên mục tiêu, audience, traffic source và awareness level.

---

| Format | Đặc điểm | Phù hợp |
|---|---|---|
| Section-based | Chia thành các section rõ ràng | SaaS, dịch vụ, sản phẩm |
| Advertorial | Viết như bài báo / bài chia sẻ | Affiliate, native ads, pre-sell |
| Sales Letter | Viết như thư bán hàng dài | Khóa học, coaching, high-ticket |
| VSL Page | Video làm trung tâm | Coaching, webinar, info product |
| Squeeze Page | Trang ngắn lấy lead | Ebook, checklist, webinar |
| Quiz Page | Dẫn người dùng qua câu hỏi | Tư vấn, health, beauty, B2B |
| Comparison Page | So sánh sản phẩm / giải pháp | SEO, SaaS, affiliate |
| Review Page | Review một sản phẩm | Affiliate, product marketing |
| Pricing Page | Tập trung vào bảng giá | SaaS, subscription |
| Product Demo Page | Tập trung vào demo / cách hoạt động | SaaS, app, tool |

---

## Hướng dẫn chọn format theo tình huống

| Tình huống | Format phù hợp |
|---|---|
| Traffic lạnh, sản phẩm phức tạp, giá cao | Sales Letter / Advertorial |
| Traffic nóng, sản phẩm đơn giản | Section-based ngắn / Squeeze Page |
| Cần demo hoặc giải thích bằng video | VSL Page |
| Native ads, cần giáo dục trước khi bán | Advertorial |
| Khách đang so sánh đối thủ | Comparison Page |
| Sản phẩm cần trải nghiệm thử | Product Demo Page |
| Thu lead, ma sát thấp | Squeeze Page |
| Khách cần cá nhân hóa tư vấn | Quiz Page |

---

## Kết hợp format theo awareness level

| Awareness Level | Format ưu tiên |
|---|---|
| Unaware | Advertorial / Sales Letter |
| Problem-aware | Advertorial / Sales Letter / Section-based dài |
| Solution-aware | Comparison Page / Section-based |
| Product-aware | Section-based / VSL Page / Pricing Page |
| Most-aware | Squeeze Page / Pricing Page |